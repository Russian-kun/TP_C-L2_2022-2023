#ifndef GRAPHIQUE_H
#define GRAPHIQUE_H
#include "common.h"
#define MINX 55
#define MINY 19

void afficher_duree(int y, int x, int nb_ms);

void afficher_interface(Chronometre chrono);

void afficher_flash();

#endif